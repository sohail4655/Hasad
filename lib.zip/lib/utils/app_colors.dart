import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Color(0xff04CC8F);
  static const backgroundColor = Color(0xffe6faf4);
  static const textColor = Color(0xff161B1D);
  static const containerColor = Color(0xff1D1B27);
  static const greyElementColor = Color(0xff979798);
}
