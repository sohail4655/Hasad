# Plants Selling App UI
This is a beautiful Flutter UI design of a plant-selling app inspired by this [dribbble design](https://dribbble.com/shots/17378824-Planting-Plant-Website).
## Preview:
If you liked the design feel free to start the repo, and use some/all its components for your own projects.

Don't forget to check my website at [yassinebenkhay.com](https://yassinebenkhay.com) if you want to learn more about Flutter.

![Scrrenshot](https://github.com/yassine-bennkhay/plants_selling_flutter_app_ui/blob/main/screenshots/plants_selling%20app_showcase.png?raw=true)
